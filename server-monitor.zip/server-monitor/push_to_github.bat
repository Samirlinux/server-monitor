@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ======================================================
echo   رفع مشروع Server & Mail Monitor على حسابك في GitHub
echo ======================================================
echo.

if not exist .git (
    git init
    git branch -M main
)

git add .
git commit -m "Initial commit: Real-time Linux Server, Uptime, Services & Mail/Spam Monitor"

echo.
set /p REPO_URL="انسخ رابط المستودع (Repository URL) من حسابك في GitHub والصقه هنا (مثال: https://github.com/USERNAME/server-monitor.git): "

if "%REPO_URL%"=="" (
    echo لم يتم إدخال الرابط.
    pause
    exit /b 1
)

git remote remove origin 2>nul
git remote add origin %REPO_URL%
git push -u origin main

echo.
echo ======================================================
echo ✅ تم رفع المشروع بنجاح على حسابك في GitHub!
echo لتسطيبه على أي سيرفر لينكس استخدم الأمر:
echo git clone %REPO_URL% ^&^& cd server-monitor ^&^& chmod +x install.sh ^&^& sudo ./install.sh
echo ======================================================
pause
